package br.com.alura.codechella;

public enum Definicao {
    INTEIRA,
    ESTUDANTE,
    IDOSO,
    PCD,
    MEIA,
    OUTROS
}
