package br.com.alura.codechella;

public record DadosTipoIngresso(
        Integer codigo,
        Formato formato,
        Definicao definicao
) {
}
