package br.com.alura.codechella;

public enum Categoria {
    FESTIVAL,
    MUSICA,
    TEATRO,
    OUTROS
}
