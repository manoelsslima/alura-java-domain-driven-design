package br.com.alura.codechella;

public enum Formato {
    PISTA,
    PISTA_PREMIUM,
    CADEIRA,
    CAMAROTE
}
